These graphs were created on R on 15 February 2024 by Ananya Iyengar. 

Data Source: Census of India 1881, Appendix G - Sections on Bombay. 

Notes: In each graph, "literacy" stands for the Percentage of Literates and Pupils. Note that for the Age Groups 5-15 and 15+, this figure is presented as a combined sum of Literates and Pupils. For data on All Age Groups, the data for Literates and Pupils has been stated separately in the Census document, and has been added to be comparable to the other graphs. 